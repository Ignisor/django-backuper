from distutils.core import setup, Extension

setup(name='django-backuper',
      version='0.1',
      description='Creates backup of database and sends it to remote server',
      author='German Gensetskiy (Ignisor)',
      author_email='Ignis2497@gmail.com',
      url='gmail.com',
      install_requires=['django-q', 'redis', 'requests', 'django-dbbackup'],
      packages=['backuper_app',
                'backuper_app.migrations',
                'backuper_app.management',
                'backuper_app.management.commands',]
      )