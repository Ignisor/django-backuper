from django.core.management.base import BaseCommand, CommandError
from backuper_app import backup


class Command(BaseCommand):
    help = 'Creates new backup and sends it to remote server'

    def handle(self, *args, **options):
        backup.async_backup()