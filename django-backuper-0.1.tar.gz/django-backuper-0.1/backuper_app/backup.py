import os.path
import zipfile
import time
import requests
from django.conf import settings
from django.core import management
from requests.auth import HTTPBasicAuth
from django_q.tasks import async


def async_backup():
    try:
        settings.BACKUPER_PROJECT_NAME
        settings.BACKUPER_SERVER_URL
        settings.BACKUPER_SERVER_LOGIN
        settings.BACKUPER_SERVER_PASSWORD

    except AttributeError:
        raise AttributeError("Please, add needed settings to settings.py")

    async(create)


def create():

    #assert settings.BACKUPER_SERVER_URL, "Please, provide server url in settings (BACKUPER_SERVER_URL)"

    management.call_command('dbbackup')
    db_path = os.path.abspath(os.path.join(settings.DBBACKUP_STORAGE_OPTIONS['location'],
                                           settings.DBBACKUP_FILENAME_TEMPLATE))
    media_path = os.path.abspath(os.path.join(settings.DBBACKUP_STORAGE_OPTIONS['location'],
                                              settings.DBBACKUP_MEDIA_FILENAME_TEMPLATE))
    compression = zipfile.ZIP_DEFLATED
    name = 'backup_{day}.zip'.format(day=time.strftime('%d'))

    zf = zipfile.ZipFile(name, mode='w')

    if os.path.isfile(db_path):
        zf.write(db_path, os.path.basename(db_path), compress_type=compression)
    if os.path.isfile(media_path):
        zf.write(media_path, os.path.basename(media_path), compress_type=compression)

    zf.close()

    data = {
        "project": settings.BACKUPER_PROJECT_NAME,
    }

    try:
        requests.post(settings.BACKUPER_SERVER_URL,
                      data=data,
                      files={"file": open(name, 'rb'), },
                      auth=HTTPBasicAuth(settings.BACKUPER_SERVER_LOGIN, settings.BACKUPER_SERVER_PASSWORD))

    except requests.ConnectionError:
        print('Can\'t connect to remote backup server: ' + settings.BACKUPER_SERVER_URL)

    finally:
        os.remove(name)

        if os.path.isfile(db_path):
            os.remove(db_path)
        if os.path.isfile(media_path):
            os.remove(media_path)
